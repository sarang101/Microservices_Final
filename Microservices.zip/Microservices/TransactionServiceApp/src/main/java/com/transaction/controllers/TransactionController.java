package com.transaction.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.transaction.exceptions.TransactionNotFound;
import com.transaction.models.Transaction;
import com.transaction.models.TransactionDTO;
import com.transaction.services.TransactionService;

@RestController
public class TransactionController {

	@Autowired
	TransactionService tranService;

	@PostMapping("/createTransaction")
	public ResponseEntity<Object> createTransaction(@RequestBody Transaction trans){
		if(tranService.createTransaction(trans)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	@PostMapping("/updateTransaction")
	public ResponseEntity<Object> updateTransaction(@RequestBody Transaction trans){
		if(tranService.updateTransaction(trans)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	@DeleteMapping("/deleteTransaction/{tranid}")
	public ResponseEntity<Object> deleteTransaction(@PathVariable("tranid") int tranId) throws TransactionNotFound{
		tranService.deleteTransaction(tranId);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);		
	}
	
	@GetMapping("/gettransaction/{tranid}")
	public Transaction getTransaction(@PathVariable("tranid") int tranId) {
		return tranService.getTransaction(tranId);
	}

	@GetMapping("/getalltransactionbyaccnum/{accnum}")
	public List<Transaction> getAllTransactionByAccNumber(@PathVariable("accnum") long accnum) {
		return tranService.getAllTransactionByAccNumber(accnum);
	}

	@GetMapping("/getalltransaction")
	public ResponseEntity<TransactionDTO> getAllTransactionList(){
		TransactionDTO dto=new TransactionDTO();
		dto.setList(tranService.getAllTransaction());
		return new ResponseEntity<TransactionDTO>(dto,HttpStatus.OK);
	}

}
