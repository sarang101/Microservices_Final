package com.transaction.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transaction.dao.TransactionDao;
import com.transaction.models.Transaction;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionDao tranDao;

	@Override
	public boolean createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		tranDao.save(transaction);
		return true;
	}

	@Override
	public boolean updateTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		tranDao.save(transaction);
		return true;
	}

	@Override
	public boolean deleteTransaction(int tranId) {
		// TODO Auto-generated method stub
		tranDao.deleteById(tranId);
		return true;
	}

	@Override
	public Transaction getTransaction(int tranId) {
		// TODO Auto-generated method stub
		Optional<Transaction> optional = tranDao.findById(tranId);
		return optional.get();
	}

	@Override
	public List<Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		return tranDao.findAll();
	}

	@Override
	public List<Transaction> getAllTransactionByAccNumber(long accNumber) {
		// TODO Auto-generated method stub
		return tranDao.getAllTransactionByAccNumber(accNumber);
	}

}
