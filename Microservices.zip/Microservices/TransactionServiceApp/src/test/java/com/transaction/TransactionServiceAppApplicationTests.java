package com.transaction;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.transaction.dao.TransactionDao;
import com.transaction.models.Transaction;
import com.transaction.services.TransactionService;

//{
//"tranId":1,
//"tranFromAccount":501,
//"tranToAccount":502,
//"tranAmount":10000,
//"tranTime":"2001-04-10 12:11:06",
//"tranType":"Fund transfer:NEFT",
//"tranStatus":"success"
//
//}

@SpringBootTest
class TransactionServiceAppApplicationTests {

	
	@Autowired
	TransactionService tranService;
	
	@MockBean
	TransactionDao dao;
	
	@Test
	public void testAddTransaction() {
		Transaction transaction = new Transaction(1,1,2, 10000.0, new Date(),"Fund transfer:NEFT","success");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		boolean res = tranService.createTransaction(transaction);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	public void testUpdateTransaction() {
		Transaction transaction = new Transaction(1,1,2, 10000.0, new Date(),"Fund transfer:NEFT","success");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		boolean res = tranService.updateTransaction(transaction);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
    public void testDeleteTransaction(){
		int transactionId = 1;
		Transaction transaction = new Transaction();
        Mockito.when(dao.findById(transactionId)).thenReturn(Optional.of(transaction));
 
        boolean res = tranService.deleteTransaction(transactionId);
        System.out.println(res);
		assertTrue(res);
    }
	

}
