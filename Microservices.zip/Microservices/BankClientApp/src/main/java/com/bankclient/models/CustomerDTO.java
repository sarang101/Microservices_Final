package com.bankclient.models;

import java.util.List;



public class CustomerDTO {

	private List<Customer> list;

	@Override
	public String toString() {
		return "customerDTO [list=" + list + "]";
	}

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}
}
