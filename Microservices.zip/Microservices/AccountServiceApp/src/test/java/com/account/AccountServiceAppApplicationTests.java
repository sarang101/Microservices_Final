package com.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.account.dao.AccountDao;
import com.account.exceptions.AccountNotFoundException;
import com.account.exceptions.NotEnoughBalanceException;
import com.account.models.Account;
import com.account.services.AccountService;

//{
//"accNumber":501,
//"accBalance":1000,
//"accBranch":"Pune-east",
//"accOpenDate":"01-01-2020",
//"accType":"saving"
//
//}

@SpringBootTest
class AccountServiceAppApplicationTests {

	@Autowired
	AccountService accService;
	
	@MockBean
	AccountDao dao;
	
	
	@Test
	public void testAddAccount() {
		Account account = new Account(1,1000,"Pune-East","01-01-2020","saving");
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean res = accService.createAccount(account);
		System.out.println(res);
		assertTrue(res);
	}

	@Test
	public void testUpdateAccount() {
		Account account = new Account(1,1000,"Pune-East","01-01-2020","saving");
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean res = accService.updateAccount(account);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
    public void testDeleteAccount() {
		long accountId = 1;
		Account account = new Account();
        Mockito.when(dao.findById(accountId)).thenReturn(Optional.of(account));
        
        boolean res = accService.deleteAccount(accountId);
        System.out.println(res);
		assertTrue(res);
    }
	
	@Test
    public void testDeposit() throws AccountNotFoundException {
        Account account = new Account();
        double amount = 500.0;
 
        Mockito.when(dao.findById(anyLong())).thenReturn(Optional.of(account));
        doNothing().when(dao).depositAccount(anyLong(), anyDouble());
 
        boolean result = accService.depositAccount(anyLong(), amount);
 
        System.out.println(result);
		assertTrue(result);
    }
	

}
