package com.account.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.dao.AccountDao;
import com.account.exceptions.AccountNotFoundException;
import com.account.exceptions.NotEnoughBalanceException;
import com.account.models.Account;
import com.account.models.Transaction;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao accDao;

	@Autowired
	TransactionService tranService;

	@Override
	public boolean createAccount(Account account) {
		// TODO Auto-generated method stub
		accDao.save(account);
		return true;
	}

	@Override
	public boolean updateAccount(Account account) {
		// TODO Auto-generated method stub
		accDao.save(account);
		return true;
	}

	@Override
	public boolean deleteAccount(long accNumber) {
		// TODO Auto-generated method stub
		accDao.deleteById(accNumber);
		return true;
	}

	@Override
	public Account getAccount(long accNumber)  {
		// TODO Auto-generated method stub
		Optional<Account> optional = accDao.findById(accNumber);
		return optional.get();
	

	}

	@Override
	public List<Account> getAccountList() {
		// TODO Auto-generated method stub
		return accDao.findAll();
	}

	@Override
	public boolean depositAccount(long accNumber, double amount) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> optional = accDao.findById(accNumber);
		if (optional.isPresent()) {
			accDao.depositAccount(accNumber, amount);
			return true;
		} else {
			throw new AccountNotFoundException("Account number is wrong!");
		}
	}

	@Override
	public boolean withdrawAccount(long accNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> optional = accDao.findById(accNumber);
		if (optional.isPresent()) {
			Account acc = optional.get();
			double currBalance = acc.getAccBalance();
			if (currBalance < amount) {
				throw new NotEnoughBalanceException("Balance is not sufficient !");
			} else {
				accDao.withdrawAccount(accNumber, amount);
				return true;
			}
		} else {
			throw new AccountNotFoundException("Account number is wrong !");
		}

	}

	@Override
	public boolean FundTransferAccount(long fromAccNumber, long toAccNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {

		Optional<Account> optional = accDao.findById(fromAccNumber);
		Optional<Account> optional1 = accDao.findById(toAccNumber);
		if (optional.isPresent() & optional1.isPresent()) {
			Account acc = optional.get();
			double currBalance = acc.getAccBalance();
			if (currBalance < amount) {
				;
				Transaction tran = new Transaction(fromAccNumber, toAccNumber, amount, new Date(), "Fund transfer",
						"failed");
				tranService.createTransaction(tran);
				throw new NotEnoughBalanceException("Balance is not sufficient !");

			} else {
				accDao.withdrawAccount(fromAccNumber, amount);
				accDao.depositAccount(toAccNumber, amount);
				Transaction tran = new Transaction(fromAccNumber, toAccNumber, amount, new Date(), "Fund transfer",
						"Success");
				tranService.createTransaction(tran);
				return true;
			}
		} else {
			Transaction tran = new Transaction(fromAccNumber, toAccNumber, amount, new Date(), "Fund transfer",
					"failed");
			tranService.createTransaction(tran);
			throw new AccountNotFoundException("Account number is wrong !");
		}

	}

}
