package com.customer;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.customer.dao.CustomerDao;
import com.customer.exceptions.CustomerNotFound;
import com.customer.models.Customer;
import com.customer.services.CustomerService;

//{
//"cusId":501,
//"cusName":"sarang",
//"cusEmail":"sarang@gmail.com",
//"cusMob":12345678,
//"cusAadhar":3456789,
//"cusPrmaAdd":"Delhi",
//"cusResiAdd":"Pune",
//"cusDob":"29-12-2002";
//}

@SpringBootTest
public class CustomerServiceAppApplicationTests {
	
	@Autowired
	CustomerService cusService;
	@MockBean
	CustomerDao dao;
	
	@Test
	public void testAddCustomer() {
		Customer customer = new Customer(1,"sarang","sarang@gmail.com", 456785677l, 3456789, "Delhi","Pune","29-12-2002");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = cusService.createCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}

	@Test
	public void testUpdateCustomer() {
		Customer customer = new Customer(1,"sarang","sarang@gmail.com", 456785677l, 3456789, "Delhi","Pune","29-12-2002");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = cusService.updateCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
    public void testDeleteCustomer() throws CustomerNotFound {
		int customerId = 1;
        Customer customer = new Customer();
        Mockito.when(dao.findById(customerId)).thenReturn(Optional.of(customer));
 
        boolean res = cusService.deleteCustomer(customerId);
        System.out.println(res);
		assertTrue(res);
    }
}
